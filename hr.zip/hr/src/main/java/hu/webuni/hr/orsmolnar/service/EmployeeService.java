package hu.webuni.hr.orsmolnar.service;

import hu.webuni.hr.orsmolnar.model.Employee;

public interface EmployeeService {

//	public int getPayRaisePercent(Employee employee);
	
	public double getPayRaisePercent(Employee employee);
}
