package hu.webuni.hr.orsmolnar;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HrApplicationTests {

	@Test
	void contextLoads() {
	}

}
